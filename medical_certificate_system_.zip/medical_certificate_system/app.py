import os
from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
import csv
from werkzeug.utils import secure_filename

app = Flask(__name__)


# --------------------------------------- Database Configuration -------------------------------------------------------------------------------------------------------------------------------------------------------------- #

# Adding configuration for using a sqlite database

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
app.config["UPLOAD_FOLDER"] = "uploads"

# Creating an SQLAlchemy instance
db = SQLAlchemy(app)


class student(db.Model):
    stu_id = db.Column(db.Integer, primary_key=True)
    stu_name = db.Column(db.String(100), nullable=False)
    stu_email = db.Column(db.String(100), nullable=False)
    stu_password = db.Column(db.String(100), nullable=False)
    stu_dep = db.Column(db.String(100), nullable=False)
    stu_sec = db.Column(db.String(100), nullable=False)
    stu_classes = db.Column(db.String(100), nullable=False)
    stu_sem = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"student('{self.stu_name}','{self.stu_email}','{self.stu_password}','{self.stu_dep}','{self.stu_sec}','{self.stu_classes}','{self.stu_sem}')"


class teacher(db.Model):
    tea_id = db.Column(db.Integer, primary_key=True)
    tea_name = db.Column(db.String(100), nullable=False)
    tea_email = db.Column(db.String(100), nullable=False)
    tea_password = db.Column(db.String(100), nullable=False)
    tea_dep = db.Column(db.String(100), nullable=False)
    tea_sec = db.Column(db.String(100), nullable=False)
    tea_sem = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"teacher('{self.tea_name}','{self.tea_email}','{self.tea_password}','{self.tea_dep}','{self.tea_sec}','{self.tea_sem}')"


class Doctor(db.Model):
    doc_id = db.Column(db.Integer, primary_key=True)
    doc_name = db.Column(db.String(100), nullable=False)
    doc_email = db.Column(db.String(100), nullable=False)
    doc_password = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"Doctor('{self.doc_name}', '{self.doc_email}', '{self.doc_password}')"


class medical_student_add(db.Model):
    med_stu_id = db.Column(db.Integer, primary_key=True)
    med_stu_name = db.Column(db.String(100), nullable=False)
    med_stu_dep = db.Column(db.String(100), nullable=False)
    med_stu_semester = db.Column(db.String(100), nullable=False)
    med_stu_section = db.Column(db.String(100), nullable=False)
    med_stu_advisor = db.Column(db.String(100), nullable=False)
    med_stu_date_for_mc = db.Column(db.String(100), nullable=False)
    med_cer_file_upload = db.Column(db.String(100), nullable=False)
    med_stu_blood_group = db.Column(db.String(100), nullable=False)
    med_stu_height = db.Column(db.String(100), nullable=False)
    med_stu_weight = db.Column(db.String(100), nullable=False)
    med_stu_remarks = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"medical_student_add('{self.med_stu_id}','{self.med_stu_name}', '{self.med_stu_dep}', '{self.med_stu_semester}', '{self.med_stu_section}', '{self.med_stu_advisor}', '{self.med_stu_date_for_mc}', '{self.med_cer_file_upload}', '{self.med_stu_blood_group}', '{self.med_stu_height}', '{self.med_stu_weight}', '{self.med_stu_remarks}')"


class med_cer_approval_teacher(db.Model):
    med_cer_approval_teacher_id = db.Column(db.Integer, primary_key=True)
    med_cer_approval_teacher_approval = db.Column(db.String(100), nullable=False)
    med_cer_stu_id = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"med_cer_approval_teacher('{self.med_cer_approval_teacher_id}','{self.med_cer_approval_teacher_approval}', '{self.med_cer_stu_id}')"


# Define the models
class medical_approved_data(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    semester = db.Column(db.String(100), nullable=False)
    section = db.Column(db.String(100), nullable=False)
    advisor = db.Column(db.String(100), nullable=False)
    date_for_mc = db.Column(db.String(100), nullable=False)
    cer_file_upload = db.Column(db.String(100), nullable=False)
    blood_group = db.Column(db.String(100), nullable=False)
    height = db.Column(db.String(100), nullable=False)
    weight = db.Column(db.String(100), nullable=False)
    remarks = db.Column(db.String(100), nullable=False)
    approval_status = db.Column(db.String(100), nullable=False, default="Pending")

    def __repr__(self):
        return f"medical_approved_data('{self.id}', '{self.name}', '{self.department}', '{self.semester}', '{self.section}', '{self.advisor}', '{self.date_for_mc}', '{self.cer_file_upload}', '{self.blood_group}', '{self.height}', '{self.weight}', '{self.remarks}', '{self.approval_status}')"


# Defining the model for the user form details


class userforms(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    roll_no = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(100), nullable=False)
    section = db.Column(db.String(100), nullable=False)
    class_studying = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"UserForm('{self.name}', '{self.roll_no}', '{self.email}', '{self.phone}', '{self.section}', '{self.class_studying}', '{self.photo}')"


class tea_userforms(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    roll_no = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(100), nullable=False)
    section = db.Column(db.String(100), nullable=False)
    class_advisor = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"UserForm('{self.name}', '{self.roll_no}', '{self.email}', '{self.phone}', '{self.section}', '{self.class_advisor}')"


class doc_userform(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    doctor_id = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"doc_userform('{self.name}', '{self.doctor_id}', '{self.email}', '{self.phone}')"


# ------------------------------------------------------------------- Routes --------------------------------------------------------------------------------------------------------------------------------------------------- #


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/sign_up")
def sign_up():
    return render_template("sign_up.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username[:3] == "stu":
            # checking the username and password in the database
            student_data = student.query.filter_by(
                stu_name=username, stu_password=password
            ).first()
            if student_data is None:
                return render_template("add_student.html")
            else:
                return render_template("student.html", student_data=student_data)
        elif username[:3] == "tea":
            # checking the username and password in the database
            teacher_data = teacher.query.filter_by(
                tea_name=username, tea_password=password
            ).first()
            if teacher_data is None:
                return render_template("add_teacher.html")
            else:
                return render_template("teacher.html", teacher_data=teacher_data)
        elif username[:3] == "doc":
            # checking the username and password in the database
            doctor_data = Doctor.query.filter_by(
                doc_name=username, doc_password=password
            ).first()
            if doctor_data is None:
                return render_template("add_doctor.html")
            else:
                return render_template("doctor.html", doctor_data=doctor_data)
        else:
            return render_template("login.html")
    else:
        return render_template("login.html")


@app.route("/medical_stu_page", methods=["GET", "POST"])
def medical_stu_page():
    return render_template("medical_stu_page.html")


# -----------------------------------------------------------User Form-------------------------------------------------------------------------------------------------------------------------------------#
@app.route("/userform", methods=["GET", "POST"])
def userform():
    if request.method == "POST":
        name = request.form["username"]
        roll_no = request.form["userrollno"]
        email = request.form["useremail"]
        phone = request.form["userphone"]
        section = request.form["usersection"]
        class_studying = request.form["userclass"]

        user_form_data = userforms(
            name=name,
            roll_no=roll_no,
            email=email,
            phone=phone,
            section=section,
            class_studying=class_studying,
        )

        db.session.add(user_form_data)
        db.session.commit()

        return render_template("index.html")
    else:
        return render_template("user_form.html")


@app.route("/for_userform", methods=["GET", "POST"])
def for_userform():
    return render_template("user_form.html")


@app.route("/user_details_viewer/<username>")
def user_details_viewer(username):
    user_data = userforms.query.filter_by(name=username).all()
    return render_template("user_details_viewer.html", user_data=user_data)


# @app.route('/userform_viewer', methods=["GET", "POST"])
# def userform_viewer():


# -----------------------------------------------------------Teacher User Form-------------------------------------------------------------------------------------------------------------------------------------#


@app.route("/tea_userform", methods=["GET", "POST"])
def tea_userform():
    if request.method == "POST":
        name = request.form["username"]
        roll_no = request.form["userrollno"]
        email = request.form["useremail"]
        phone = request.form["userphone"]
        section = request.form["usersection"]
        class_advisor = request.form["userclass"]

        tea_user_form_data = tea_userforms(
            name=name,
            roll_no=roll_no,
            email=email,
            phone=phone,
            section=section,
            class_advisor=class_advisor,
        )

        db.session.add(tea_user_form_data)
        db.session.commit()

        return render_template("index.html")
    else:
        return render_template("tea_user_form.html")


@app.route("/for_tea_userform", methods=["GET", "POST"])
def for_tea_userform():
    return render_template("tea_user_form.html")


@app.route("/tea_user_details_viewer/<username>")
def tea_user_details_viewer(username):
    tea_user_data = tea_userforms.query.filter_by(name=username).all()
    return render_template("tea_user_details_viewer.html", tea_user_data=tea_user_data)


# -------------------------------------------------------------------- Doctor User Form -----------------------------------------------------------------------------------------------------------------------------------#
@app.route("/doc_userforms", methods=["GET", "POST"])
def doc_userforms():
    if request.method == "POST":
        name = request.form["username"]
        doctor_id = request.form["userdocid"]
        email = request.form["useremail"]
        phone = request.form["userphone"]

        doc_user_form_data = doc_userform(
            name=name,
            doctor_id=doctor_id,
            email=email,
            phone=phone,
        )

        db.session.add(doc_user_form_data)
        db.session.commit()

        return render_template("index.html")
    else:
        return render_template("doc_user_form.html")


@app.route("/for_doc_userform", methods=["GET", "POST"])
def for_doc_userform():
    return render_template("doc_user_form.html")


@app.route("/doc_user_details_viewer/<username>")
def doc_user_details_viewer(username):
    doc_user_data = doc_userform.query.filter_by(name=username).all()
    return render_template("doc_user_details_viewer.html", doc_user_data=doc_user_data)


# -----------------------------------------------------------Adding everything to the database-------------------------------------------------------------------------------------------------------------------------------------#


@app.route("/add_student", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        stu_name = request.form["stu_name"]
        stu_email = request.form["stu_email"]
        stu_password = request.form["stu_password"]
        stu_dep = request.form["stu_dep"]
        stu_sec = request.form["stu_sec"]
        stu_classes = request.form["stu_classes"]
        stu_sem = request.form["stu_sem"]

        # creating an instance of the class student
        student_data = student(
            stu_name=stu_name,
            stu_email=stu_email,
            stu_password=stu_password,
            stu_dep=stu_dep,
            stu_sec=stu_sec,
            stu_classes=stu_classes,
            stu_sem=stu_sem,
        )

        # adding the data to the database
        db.session.add(student_data)
        db.session.commit()

        return render_template("login.html")
    else:
        return render_template("add_student.html")


@app.route("/add_teacher", methods=["GET", "POST"])
def add_teacher():
    if request.method == "POST":
        tea_name = request.form["tea_name"]
        tea_email = request.form["tea_email"]
        tea_password = request.form["tea_password"]
        tea_dep = request.form["tea_dep"]
        tea_sec = request.form["tea_sec"]
        tea_sem = request.form["tea_sem"]

        # creating an instance of the class student
        teacher_data = teacher(
            tea_name=tea_name,
            tea_email=tea_email,
            tea_password=tea_password,
            tea_dep=tea_dep,
            tea_sec=tea_sec,
            tea_sem=tea_sem,
        )

        # adding the data to the database
        db.session.add(teacher_data)
        db.session.commit()

        return render_template("login.html")
    else:
        return render_template("add_teacher.html")


@app.route("/add_doctor", methods=["GET", "POST"])
def add_doctor():
    if request.method == "POST":
        doc_name = request.form["doc_name"]
        doc_email = request.form["doc_email"]
        doc_password = request.form["doc_password"]

        # creating an instance of the class student
        doctor_data = Doctor(
            doc_name=doc_name, doc_email=doc_email, doc_password=doc_password
        )

        # adding the data to the database
        db.session.add(doctor_data)
        db.session.commit()

        return render_template("login.html")

    else:
        return render_template("add_doctor.html")


@app.route("/add_student_medical", methods=["GET", "POST"])
def add_student_medical():
    if request.method == "POST":
        med_stu_name = request.form["med_stu_name"]
        med_stu_dep = request.form["med_stu_dep"]
        med_stu_semester = request.form["med_stu_semester"]
        med_stu_section = request.form["med_stu_section"]
        med_stu_advisor = request.form["med_stu_advisor"]
        med_stu_date_for_mc = request.form["med_stu_date_for_mc"]
        med_stu_blood_group = request.form["med_stu_blood_group"]
        med_stu_height = request.form["med_stu_height"]
        med_stu_weight = request.form["med_stu_weight"]
        med_stu_remarks = request.form["med_stu_remarks"]

        # Get the file data from the request
        med_cer_file_upload = request.files["med_cer_file_upload"]

        # Save the file to a desired location
        file_name = secure_filename(med_cer_file_upload.filename)
        med_cer_file_upload.save(os.path.join(app.config["UPLOAD_FOLDER"], file_name))

        # creating an instance of the class student
        medical_student_data = medical_student_add(
            med_stu_name=med_stu_name,
            med_stu_dep=med_stu_dep,
            med_stu_semester=med_stu_semester,
            med_stu_section=med_stu_section,
            med_stu_advisor=med_stu_advisor,
            med_stu_date_for_mc=med_stu_date_for_mc,
            med_cer_file_upload=file_name,  # Save the file name in the database
            med_stu_blood_group=med_stu_blood_group,
            med_stu_height=med_stu_height,
            med_stu_weight=med_stu_weight,
            med_stu_remarks=med_stu_remarks,
        )

        # adding the data to the database
        db.session.add(medical_student_data)
        db.session.commit()

        return render_template("doctor.html")

    else:
        return render_template("doctor.html")


# -------------------------------------------------------------Downloading the csv file in Doctor Side----------------------------------------------------------------------------------------------------------------------------------#


@app.route("/download_med_stu_csv")
def download_med_stu_csv():
    med_stu_data = medical_student_add.query.all()
    csv_file_name = "medical_history.csv"
    with open(csv_file_name, "w", newline="") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(
            [
                "med_stu_id",
                "med_stu_name",
                "med_stu_dep",
                "med_stu_semester",
                "med_stu_section",
                "med_stu_advisor",
                "med_stu_date_for_mc",
                "med_cer_file_upload",
                "med_stu_blood_group",
                "med_stu_height",
                "med_stu_weight",
                "med_stu_remarks",
            ]
        )
        for data in med_stu_data:
            csv_writer.writerow(
                [
                    data.med_stu_id,
                    data.med_stu_name,
                    data.med_stu_dep,
                    data.med_stu_semester,
                    data.med_stu_section,
                    data.med_stu_advisor,
                    data.med_stu_date_for_mc,
                    data.med_cer_file_upload,
                    data.med_stu_blood_group,
                    data.med_stu_height,
                    data.med_stu_weight,
                    data.med_stu_remarks,
                ]
            )

    return render_template("doctor.html", csv_file_name=csv_file_name)


@app.route("/medcerapprovalteacher", methods=["GET", "POST"])
def medcerapprovalteacher():
    med_stu_data = medical_student_add.query.all()
    return render_template("teacher.html", med_stu_data=med_stu_data)


# ------------------------------------------------File Upload-----------------------------------------------------------------------------------------------------------------------------------------------------------------#

# @app.route('/uploads', methods=['GET', 'POST'])
# def uploads():
#     if 'file' not in request.files:
#         return "No file found"
#     file = request.files['file']
#     if file.filename == '':
#         return "No file found"
#     file.save('uploads/'+file.filename)

#     return "File Uploaded Successfully"


# ------------------------------------------------Teacher Side-----------------------------------------------------------------------------------------------------------------------------------------------------------------#

# getting the data from the database and displaying it in the teacher.html page only if the teacher username and name in the database matches


@app.route("/med_cer_viewer_teacher", methods=["GET", "POST"])
def med_cer_viewer_teacher():
    user_name = request.form["user_name"]
    med_stu_data = medical_student_add.query.filter_by(med_stu_advisor=user_name).all()
    return render_template("main_teacher.html", med_stu_data=med_stu_data)

    # med_stu_data = medical_student_add.query.filter_by(med_stu_advisor=user_name).all()
    # return render_template("teacher.html", med_stu_data=med_stu_data)


@app.route("/md_teacher", methods=["GET", "POST"])
def md_teacher():
    return render_template("md_teacher.html")


@app.route("/md_cer_accepter", methods=["GET", "POST"])
def md_cer_accepter():
    med_cer_stu_id = request.form["med_cer_stu_id"]
    med_cer_approval_teacher_approval = request.form[
        "med_cer_approval_teacher_approval"
    ]
    med_cer_approval_teacher_data = med_cer_approval_teacher(
        med_cer_stu_id=med_cer_stu_id,
        med_cer_approval_teacher_approval=med_cer_approval_teacher_approval,
    )

    db.session.add(med_cer_approval_teacher_data)
    db.session.commit()
    return render_template("md_teacher.html")


@app.route("/med_approval_saver_csv", methods=["GET", "POST"])
def med_approval_saver_csv():
    med_cer_approval_teacher_data = med_cer_approval_teacher.query.all()
    csv_file_name = "medical_approval.csv"
    with open(csv_file_name, "w", newline="") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(
            [
                "med_cer_approval_teacher_id",
                "med_cer_approval_teacher_approval",
                "med_cer_stu_id",
            ]
        )
        for data in med_cer_approval_teacher_data:
            csv_writer.writerow(
                [
                    data.med_cer_approval_teacher_id,
                    data.med_cer_approval_teacher_approval,
                    data.med_cer_stu_id,
                ]
            )
    return render_template("md_teacher.html", csv_file_name=csv_file_name)


@app.route("/med_approval_saver_csv_download", methods=["GET", "POST"])
def med_approval_saver_csv_download():
    return render_template("md_teacher.html")


@app.route("/med_cer_stu_approval_teacher", methods=["GET", "POST"])
def med_cer_stu_approval_teacher():
    student_id = request.form.get("student_id")
    student_data = med_cer_approval_teacher.query.filter_by(
        med_cer_stu_id=student_id
    ).all()
    return render_template("medical_student_app_viewer.html", student_data=student_data)


@app.route("/main_teacher", methods=["GET", "POST"])
def main_teacher():
    return render_template("main_teacher.html")


# ------------------------------------------------------------------- Running the app ------------------------------------------------------------------------------------------------------------------------------------------- #


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
